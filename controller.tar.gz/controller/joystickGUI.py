# convenience file for cases where running a module is inconvenient
import padpyght.__main__
